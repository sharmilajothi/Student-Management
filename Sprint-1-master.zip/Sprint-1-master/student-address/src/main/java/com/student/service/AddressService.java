package com.student.service;

import com.student.entity.Address;
import com.student.model.AddressDTO;

public interface AddressService {

	String createAddress(Address address);
}
